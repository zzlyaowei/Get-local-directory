/* 
 * To change this license header, choose License Headers in Project Properties.
 */
/*追加内容*/
function addNotice(self) {
    if ($(self).children('eb').length <= 0) {
        $(self).append('<eb class="notice">空文件夹!</eb>');
        setTimeout(function () {
            $(self).children('eb').fadeOut(500, function () {
                $(self).children('eb').remove();
            });
        }, 2000);
    }
}
/*获取文件状态*/
function getFileList(self) {
    if ($(self).next('li').hasClass('ml10')) {
        fileState(self, 1);
    } else {
        var url = window.location.href;
        var folderPath = $(self).children().children('.dirurl').text();
        $.post(url, {filePath: folderPath}, function (data) {
            if (data != '') {
                $(self).addClass('openList');
                $(self).after(data);
                fileState(self, 1);
            } else {
                addNotice(self);
            }
        })
    }
}
/*列表展开与隐藏*/
function fileState(self, sendtype) {
    var listOpen = $(self).attr('fOpen');
    if (listOpen == '1') {
        $(self).removeClass('list_folderopen');
        $(self).attr('fOpen', '0');
        listType(self, '0');
        $(self).next().find('div').css('display', 'none');
        $(self).next().hide(500);
        getDvheight(self);
        //规定关闭根目录即关闭所有目录
        if (sendtype == 2) {
            $(self).next('li').children('ul').find('li.fileList').each(function () {
                $(this).attr('flieType', '0');
                $(this).attr('showType', '0');
                if ($(this).attr('fOpen') != 'undefined') {
                    $(this).attr('fOpen', '0');
                }
            });
            $(self).next('li').children('ul').find('li.ml10').each(function () {
                $(this).css('display', 'none');
            });
        }
    } else {
        $(self).addClass('list_folderopen');
        $(self).attr('fOpen', '1');
        listType(self, '1');
        $(self).next().show(500, function () {
            getDvheight(self);
            $(self).next().find('div').css('display', 'block');
        });
    }
}
/*判断div高度*/
function getDvheight(obj) {
    $(obj).parents().find('.line_h').each(function () {
        var hideNum = 0;
        $(this).next('ul').find('li.fileList').each(function (i, liobj) {
            var fType = $(liobj).attr('flieType');
            var listType = $(liobj).attr('showType');
            if (fType == '1' && listType == '1') {
                hideNum++;
            }
        });
        //console.log(hideNum);
        var flength = hideNum * 30 - 16;
        $(this).height(flength + 'px');
    });
}
/*列表展开/隐藏状态*/
function listType(obj, type) {
    $(obj).next('li').children('ul').children('li.fileList').each(function () {
        $(this).attr('flieType', type);
        $(this).attr('showType', type);
    });
    if (type == '1') {
        $(obj).next('li').find('li.openList').each(function () {
            if ($(this).attr('fOpen') == '1' && $(this).attr('flieType') == '1') {
                $(this).next('li').children('ul').children('li.fileList').each(function (i, fobj) {
                    $(fobj).attr('showType', type);
                    $(fobj).attr('flieType', type);
                });
            }
        });
    } else {
        $(obj).next().find('li.fileList').each(function () {
            $(this).attr('showType', type);
        });
    }
}
/*关闭根目录*/
function closeList(self) {
    fileState(self, 2);
}
/*判断滚动条位置*/
$(function () {
    $(window).scroll(function () {
        var scTop = $(window).scrollTop();
        if (scTop > 20) {
            $('.cont_title').addClass('title_fixed');
            $('.cont_listont').addClass('mt95')
            $('.scrotop').show();
        } else {
            $('.cont_title').removeClass('title_fixed');
            $('.cont_listont').removeClass('mt95')
            $('.scrotop').hide();
        }
    })
})
/*点击回到顶部*/
function scroTop() {
    $('html,body').animate({scrollTop: 0}, function () {
        $('.cont_title').removeClass('title_fixed');
        $('.scrotop').hide();
    });
}