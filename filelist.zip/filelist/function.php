<?php

/*
 * 获取根目录下的目录树
 * $dir根目录
 */

function getDir($dirPath) {
    //$dirName = basename($dirPath); //当前目录名称
    $fileArray = array();
    $dirPath = iconv("UTF-8", 'GBK', $dirPath);
    $filePath = scandir($dirPath);
    foreach ($filePath as $fileName) {
        $fileArr = array_filter(explode('.', $fileName));
        if (!empty($fileArr)) {
            $fileParh = $dirPath . '\\' . $fileName;
            if (is_dir($fileParh)) {
                $fileArray[] = array('type' => 1, 'name' => iconv("GBK", "UTF-8", $fileName));
            } else {
                if (count($fileArr) > 1) {
                    $fileSingle = '';
                    $numcount = 0;
                    foreach ($fileArr as $file) {
                        if ($file != end($fileArr)) {
                            if ($numcount == 0) {
                                $fileSingle = $file;
                            } else {
                                $fileSingle = $fileSingle . '.' . $file;
                            }
                            $numcount++;
                        }
                    }
                    $fileArray[] = array('type' => 2, 'name' => iconv("GBK", "UTF-8", $fileSingle), 'endname' => strtolower(iconv("GBK", "UTF-8", end($fileArr))));
                } else {
                    $fileArray[] = array('type' => 3, 'name' => iconv("GBK", "UTF-8", $fileArr[0]));
                }
            }
        }
    }
    return $fileArray;
}

/*
 * 获取浏览器类型 
 */

function getBrowser() {
    global $_SERVER;
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $browser = 'unknown';
    if (strpos($agent, 'MSIE') !== false || strpos($agent, 'rv:11.0')) {
        $browser = "ie";
    } else if (strpos($agent, 'Firefox') !== false) {
        $browser = "firefox";
    } else if (strpos($agent, 'Chrome') !== false) {
        $browser = "chrome";
    } else if (strpos($agent, 'Opera') !== false) {
        $browser = 'opera';
    } else if ((strpos($agent, 'Chrome') == false) && strpos($agent, 'Safari') !== false) {
        $browser = 'safari';
    }
    return array('browser' => $browser);
}

/*
 * 输出目录内容
 */

function showList($dirPath, $opType) {
    global $difineArr;
    $fileArr = getDir($dirPath);
    $str = '';
    $str1 = '';
    $str2 = '';
    $reUrl = '';
    $rootPath = $difineArr['rootPath'];
    $pathArr = array_filter(explode($rootPath, $dirPath));
    if (!empty($pathArr)) {
        $rePath = str_replace('\\', '/', $pathArr[1]);
        $reUrl = $difineArr['host'] . '://' . $_SERVER['HTTP_HOST'] . $rePath . '/';
    } else {
        $reUrl = $difineArr['host'] . '://' . $_SERVER['HTTP_HOST'] . '/';
    }
    if (count($fileArr) > 0) {
        $browser = getBrowser(); //获取浏览器类型
        $fileoType = $difineArr['fileoType'];
        $str .= '<li class="ml10" style="display:' . ($opType == '0' ? 'none' : 'block') . '">
                <div class="line_h" style="height:' . ($dirPath == $difineArr['serverPath'] ? ((count($fileArr) - 1) * 30 - 16) : (count($fileArr) * 30 - 16)) . 'px;"></div>
                <ul class="list_ul pl15">';
        $htmlType = array('chrome', 'firefox', 'ie', 'opera', 'safari');
        foreach ($fileArr as $file) {
            switch ($file['type']) {
                case 1:
                    if (!($dirPath == $difineArr['serverPath'] && in_array($file['name'], $difineArr['serverName']))) {//不显示程序目录
                        $dirurl = $dirPath . '\\' . $file['name'];
                        $str1 .= '<li class="list_folder fileList" showType="' . $opType . '" flieType="' . $opType . '" fOpen="0" onclick="getFileList(this)"><div class="line_w"><hr class="line_hr" /><p class="none dirurl">' . $dirurl . '</p></div>' . $file['name'] . '</li>';
                    }
                    break;
                case 2:
                    $url = '';
                    $browserType = $file['endname'] == 'php' ? "php" : (($file['endname'] == 'html' && in_array($browser['browser'], $htmlType)) ? $browser['browser'] : 'unknown');
                    if ($browserType == 'unknown') {
                        foreach ($fileoType as $sinType) {
                            if (in_array($file['endname'], $sinType['type'])) {
                                $browserType = $sinType['showname'];
                            }
                        }
                    }
                    //判断是浏览器支持的文件类型，直接打开
                    $fileName = $file['name'] . '.' . $file['endname'];
                    if (in_array($file['endname'], $difineArr['urlType'])) {
                        $url = $reUrl . $fileName;
                        $url = '<a href="' . $url . '" target="_blank">' . $fileName . '</a>';
                    } else {
                        $url = $fileName;
                    }
                    $movieType = array('');
                    $str2 .= '<li class="list_file file_' . $browserType . ' fileList" showType="' . $opType . '" flieType="' . $opType . '"><div class="line_w"><hr class="line_hr" /></div>' . $url . '</li>';
                    break;
                case 3:
                    $str2 .= '<li class="list_file file_unknown fileList" showType="' . $opType . '" flieType="' . $opType . '"><div class="line_w"><hr class="line_hr" /></div>' . $file['name'] . '</li>';
                    break;
                default:
                    break;
            }
        }
        $str .= $str1;
        $str .= $str2;
        $str .= '</ul></li>';
    }
    return $str;
}

?>