<?php
header("content-type:text/html;charset=utf-8");
include_once 'function.php';
include_once 'definearr.php';
$dirPath = $difineArr['dirPath']; //当前目录
$fileArr = getDir($dirPath);
$fileList = '';
if (isset($_POST['filePath'])) {
    echo showList($_POST['filePath'], '0');
    exit();
} else {
    $fileList = showList($dirPath, '1');
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>文件目录</title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css" type="text/css" />
        <link rel="stylesheet" href="css/font-awesome.css" type="text/css" />
        <script src="js/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="js/function.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="cont">
            <div class="cont_title"><!-- title --></div>
            <div class="cont_listont">
                <ul class="list_ul">
                    <li class="list_folder fileList openList <?php
                        if (count($fileArr) > 0) {
                            echo 'list_folderopen';
                        }
                        ?>" onclick="closeList(this)" showType="1" flieType="1"  <?php
                        echo count($fileArr) > 0 ? 'fOpen="1"' : 'fOpen="0"';
                        ?>>文件根目录</li>
                        <?php echo $fileList ?>
                </ul>
            </div>
            <div class="scrotop" onclick="scroTop()"><i class="fa fa-arrow-up" aria-hidden="true"></i></div>
        </div>
    </body>
</html>