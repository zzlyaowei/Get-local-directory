<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 */
global $difineArr;
$difineArr = array(
    'rootPath' => 'C:\wamp\www', //站点根目录
    'fileoType' => array(
        array('type' => array('jpg', 'jpeg', 'png', 'bmp', 'gif'), 'showname' => 'picture'),
        array('type' => array('mp4', 'mpeg4', 'ogg', 'webm'), 'showname' => 'movie'),
        array('type' => array('mp3', 'ogg', 'wav'), 'showname' => 'music')
    ), //文件类型
    'urlType' => array('php', 'html', 'jpg', 'jpeg', 'png', 'bmp', 'gif', 'mp4', 'mpeg4', 'ogg', 'webm', 'mp3', 'ogg', 'wav'), //浏览器支持的文件类型
    'dirPath' => dirname(dirname(__FILE__)),
    'host' => 'http',
    'serverName' => array('filelist'),
    'serverPath' => 'C:\wamp\www',
);
return $difineArr;
exit();
?>